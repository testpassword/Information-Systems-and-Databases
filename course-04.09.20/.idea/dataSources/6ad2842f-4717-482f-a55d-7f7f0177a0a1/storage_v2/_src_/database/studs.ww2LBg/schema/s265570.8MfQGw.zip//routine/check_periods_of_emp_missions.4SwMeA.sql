create function check_periods_of_emp_missions() returns trigger
    language plpgsql
as
$$
DECLARE inserted_miss mission;
BEGIN
    inserted_miss = (SELECT * FROM mission WHERE miss_id = new.miss_id);
    IF (TRUE) IN (
        SELECT (inserted_miss.start_date_and_time, inserted_miss.end_date_and_time) OVERLAPS
               (start_date_and_time, end_date_and_time) FROM mission
        WHERE miss_id IN (SELECT miss_id FROM missions_emp WHERE emp_id = new.emp_id)) THEN
        RAISE EXCEPTION 'This worker cannot be assigned to a mission as he was on another mission at the time';
    ELSE RETURN new;
    END IF;
END;
$$;

alter function check_periods_of_emp_missions() owner to s265570;

