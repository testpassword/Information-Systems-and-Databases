create function close_empty_bases() returns SETOF void
    language plpgsql
as
$$
BEGIN
        DELETE FROM base WHERE base_id IN (SELECT * FROM base_count_emp);
    END;
$$;

alter function close_empty_bases() owner to s265570;

