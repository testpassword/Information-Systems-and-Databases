create function update_base_count_emp() returns trigger
    language plpgsql
as
$$
BEGIN
    REFRESH MATERIALIZED VIEW base_count_emp;
END;
$$;

alter function update_base_count_emp() owner to s265570;

