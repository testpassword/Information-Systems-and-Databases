create materialized view base_count_emp as
SELECT base.base_id
FROM base
         JOIN employee USING (base_id)
GROUP BY base.base_id
HAVING count(employee.emp_id) = 0;

alter materialized view base_count_emp owner to s265570;

