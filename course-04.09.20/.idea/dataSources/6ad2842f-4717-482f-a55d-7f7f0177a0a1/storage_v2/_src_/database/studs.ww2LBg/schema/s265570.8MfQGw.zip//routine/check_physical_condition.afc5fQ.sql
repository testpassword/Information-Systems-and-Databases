create function check_physical_condition() returns trigger
    language plpgsql
as
$$
DECLARE card medical_card;
BEGIN
    card = (SELECT height_cm, weight_kg FROM medical_card JOIN employee USING (emp_id) WHERE emp_id = new.emp_id);
    IF card.height_cm < 150 OR card.weight_kg < 45 THEN
        RAISE EXCEPTION 'Cannot hair this employee to military position because his physical data does not require the minimum';
    ELSE RETURN new;
    END IF;
END;
$$;

alter function check_physical_condition() owner to s265570;

