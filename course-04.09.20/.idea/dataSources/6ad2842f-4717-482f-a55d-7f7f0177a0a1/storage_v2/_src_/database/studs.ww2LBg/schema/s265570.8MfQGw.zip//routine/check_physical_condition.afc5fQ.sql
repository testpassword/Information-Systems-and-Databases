create function check_physical_condition() returns trigger
    language plpgsql
as
$$
DECLARE h SMALLINT;
    DECLARE w SMALLINT;
    BEGIN
        SELECT height_cm, weight_kg INTO h, w FROM medical_card JOIN employee USING (emp_id) WHERE emp_id = new.emp_id;
        IF h < 150 OR w < 45 THEN
            RAISE EXCEPTION 'Cannot hire this employee to military position because his physical data does not require the minimum';
        ELSE RETURN new;
        END IF;
    END;
$$;

alter function check_physical_condition() owner to s265570;

