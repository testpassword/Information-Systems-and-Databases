create function is_military_on_mission() returns trigger
    language plpgsql
as
$$
DECLARE enemy TEXT;
    DECLARE rank TEXT;
    BEGIN
        enemy = (SELECT enemies FROM mission WHERE miss_id = new.miss_id);
        rank = (SELECT rank FROM position JOIN employee USING (pos_id) WHERE emp_id = new.emp_id);
        IF (enemy IS NOT NULL OR !~~ '') AND (rank IS NULL OR ~~ '') THEN
            RAISE EXCEPTION 'Cannot set not military employee to a combat mission';
        ELSE RETURN new;
        END IF;
    END;
$$;

alter function is_military_on_mission() owner to postgres;

