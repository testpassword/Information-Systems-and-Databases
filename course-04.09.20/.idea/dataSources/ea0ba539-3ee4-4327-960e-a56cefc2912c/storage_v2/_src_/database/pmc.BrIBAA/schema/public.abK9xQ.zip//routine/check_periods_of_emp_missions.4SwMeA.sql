create function check_periods_of_emp_missions() returns trigger
    language plpgsql
as
$$
DECLARE start_time TIMESTAMP;
    DECLARE end_time TIMESTAMP;
    BEGIN
        SELECT start_time, end_time INTO start_time, end_time FROM mission WHERE miss_id = new.miss_id;
        IF (TRUE) IN (
            SELECT (start_time, end_time) OVERLAPS
                   (start_date_and_time, end_date_and_time) FROM mission
                WHERE miss_id IN (SELECT miss_id FROM missions_emp WHERE emp_id = new.emp_id)) THEN
            RAISE EXCEPTION 'This worker cannot be assigned to a mission as he was on another mission at the time';
        ELSE RETURN new;
        END IF;
    END;
$$;

alter function check_periods_of_emp_missions() owner to postgres;

